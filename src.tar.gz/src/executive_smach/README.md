SMACH
=====

SMACH is a task-level python execution framework for rapidly composing complex
robot behaviors.

![travis](https://travis-ci.org/jbohren/executive_smach.svg?branch=master)
